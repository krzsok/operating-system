========================================================================
Autor: Krzysztof Sokół-Szołtysek,                        Krakow, 06.05.2013
========================================================================

* Zawartosc:
============

Katalog zawiera program w jezyku C:
--------------------------------------------------------------------

I.  Program opierajacy sie na zalozeniach cwiczenia czwartego.

 
    1) 4.c  - program obslugujacy problem producent-konsument
    

------------------------------------------------------------------------

* Jak uruchomic program:
=========================

Katalog zawiera program Makefile do kompilacji, linkowania
i uruchamiania powyzszego programu

-> Aby uruchomic program, nalezy wykonac komende:
       "make" , a nastepnie "make run1"



========================================================================



